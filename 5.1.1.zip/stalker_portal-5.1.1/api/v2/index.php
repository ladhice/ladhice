<?php

require_once "../../server/common.php";

echo "API v2 deprecated";
exit;
