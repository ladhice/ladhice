<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Stalker Middleware Authorization</title>

    <link href="css/bootstrap.css" rel="stylesheet">

    <style type="text/css">
        .span6{
            margin: 100px auto;
            float: none;
        }
    </style>

</head>
<body>

<div class="span6">

  <div class="alert alert-success">
    <strong>Authorization success!</strong>
  </div>
    
</div>

</body>
</html>