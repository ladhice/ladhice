<?php

header("Location: authorize");